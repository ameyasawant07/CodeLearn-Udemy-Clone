'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { Code, BookOpen, CheckCircle, TrendingUp } from 'lucide-react';

export default function DashboardPage() {
  const router = useRouter();
  const [user, setUser] = useState<any>(null);
  const [courses, setCourses] = useState<any[]>([]);
  const [problems, setProblems] = useState<any[]>([]);
  const [submissions, setSubmissions] = useState<any[]>([]);
  const [allProblems, setAllProblems] = useState<any[]>([]);

  useEffect(() => {
    const token = localStorage.getItem('token');
    if (!token) {
      router.push('/login');
      return;
    }

    fetch('/api/user', {
      headers: { Authorization: `Bearer ${token}` },
    })
      .then(res => res.json())
      .then(data => {
        if (!data.user) {
          router.push('/login');
          return;
        }
        setUser(data.user);
        
        // Fetch courses
        fetch('/api/courses')
          .then(res => res.json())
          .then(courseData => {
            const enrolledCourses = courseData.courses?.filter((c: any) => 
              data.user.enrolledCourses?.includes(c.id)
            ) || [];
            setCourses(enrolledCourses);
          })
          .catch(() => {});

        // Fetch problems
        fetch('/api/problems')
          .then(res => res.json())
          .then(problemData => {
            const allProbs = problemData.problems || [];
            setAllProblems(allProbs);
            const solvedProblems = allProbs.filter((p: any) => 
              data.user.solvedProblems?.includes(p.id)
            );
            setProblems(solvedProblems);
          })
          .catch(() => {});

        // Fetch submissions
        fetch('/api/submissions', {
          headers: { Authorization: `Bearer ${token}` },
        })
          .then(res => res.json())
          .then(subData => {
            setSubmissions((subData.submissions || []).slice(0, 10));
          })
          .catch(() => {});
      })
      .catch(() => router.push('/login'));
  }, [router]);

  if (!user) {
    return <div className="min-h-screen flex items-center justify-center">Loading...</div>;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      <nav className="bg-white shadow-lg">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16">
            <div className="flex items-center">
              <Link href="/" className="flex items-center space-x-2">
                <Code className="h-8 w-8 text-blue-600" />
                <span className="text-2xl font-bold text-gray-900">CodeLearn</span>
              </Link>
            </div>
            <div className="flex items-center space-x-4">
              <Link href="/" className="text-gray-700 hover:text-blue-600 px-3 py-2">Home</Link>
              <Link href="/courses" className="text-gray-700 hover:text-blue-600 px-3 py-2">Courses</Link>
              <Link href="/problems" className="text-gray-700 hover:text-blue-600 px-3 py-2">Problems</Link>
            </div>
          </div>
        </div>
      </nav>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <h1 className="text-4xl font-bold text-gray-900 mb-8">Welcome back, {user.name}!</h1>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-12">
          <div className="bg-white rounded-lg shadow-lg p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-600 text-sm">Enrolled Courses</p>
                <p className="text-3xl font-bold text-gray-900">{courses.length}</p>
              </div>
              <BookOpen className="h-12 w-12 text-blue-600" />
            </div>
          </div>
          <div className="bg-white rounded-lg shadow-lg p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-600 text-sm">Solved Problems</p>
                <p className="text-3xl font-bold text-gray-900">{problems.length}</p>
              </div>
              <CheckCircle className="h-12 w-12 text-green-600" />
            </div>
          </div>
          <div className="bg-white rounded-lg shadow-lg p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-600 text-sm">Total Submissions</p>
                <p className="text-3xl font-bold text-gray-900">{submissions.length}</p>
              </div>
              <Code className="h-12 w-12 text-purple-600" />
            </div>
          </div>
          <div className="bg-white rounded-lg shadow-lg p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-600 text-sm">Success Rate</p>
                <p className="text-3xl font-bold text-gray-900">
                  {submissions.length > 0
                    ? Math.round(
                        (submissions.filter(s => s.status === 'accepted').length /
                          submissions.length) *
                          100
                      )
                    : 0}
                  %
                </p>
              </div>
              <TrendingUp className="h-12 w-12 text-yellow-600" />
            </div>
          </div>
        </div>

        {/* My Courses */}
        <div className="mb-12">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">My Courses</h2>
          {courses.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {courses.map((course) => (
                <Link key={course.id} href={`/courses/${course.id}/learn`}>
                  <div className="bg-white rounded-lg shadow-lg overflow-hidden hover:shadow-xl transition">
                    <img
                      src={course.thumbnail}
                      alt={course.title}
                      className="w-full h-48 object-cover"
                    />
                    <div className="p-6">
                      <h3 className="text-xl font-bold text-gray-900 mb-2">{course.title}</h3>
                      <p className="text-gray-600">{course.lessons.length} lessons</p>
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          ) : (
            <div className="bg-white rounded-lg shadow-lg p-8 text-center">
              <p className="text-gray-600 mb-4">You haven't enrolled in any courses yet.</p>
              <Link
                href="/courses"
                className="text-blue-600 hover:underline font-semibold"
              >
                Browse Courses →
              </Link>
            </div>
          )}
        </div>

        {/* Recent Submissions */}
        <div>
          <h2 className="text-2xl font-bold text-gray-900 mb-6">Recent Submissions</h2>
          {submissions.length > 0 ? (
            <div className="bg-white rounded-lg shadow-lg overflow-hidden">
              <table className="w-full">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                      Problem
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                      Language
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                      Status
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                      Runtime
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                      Date
                    </th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-200">
                  {submissions.map((submission) => {
                    const problem = allProblems.find(p => p.id === submission.problemId);
                    return (
                      <tr key={submission.id}>
                        <td className="px-6 py-4">
                          <Link
                            href={`/problems/${submission.problemId}`}
                            className="text-blue-600 hover:underline"
                          >
                            {problem?.title || 'Unknown'}
                          </Link>
                        </td>
                        <td className="px-6 py-4 text-gray-500">{submission.language}</td>
                        <td className="px-6 py-4">
                          <span
                            className={`px-2 py-1 text-xs font-semibold rounded-full ${
                              submission.status === 'accepted'
                                ? 'bg-green-100 text-green-800'
                                : 'bg-red-100 text-red-800'
                            }`}
                          >
                            {submission.status}
                          </span>
                        </td>
                        <td className="px-6 py-4 text-gray-500">{submission.runtime}ms</td>
                        <td className="px-6 py-4 text-gray-500">
                          {new Date(submission.submittedAt).toLocaleDateString()}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          ) : (
            <div className="bg-white rounded-lg shadow-lg p-8 text-center">
              <p className="text-gray-600 mb-4">No submissions yet.</p>
              <Link
                href="/problems"
                className="text-blue-600 hover:underline font-semibold"
              >
                Start Solving →
              </Link>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

