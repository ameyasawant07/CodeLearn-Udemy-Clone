'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';
import { BookOpen, Code, TrendingUp, Users, Star, Play } from 'lucide-react';

export default function Home() {
  const [courses, setCourses] = useState<any[]>([]);
  const [problems, setProblems] = useState<any[]>([]);
  const [user, setUser] = useState<any>(null);

  useEffect(() => {
    const token = localStorage.getItem('token');
    if (token) {
      fetch('/api/user', {
        headers: { Authorization: `Bearer ${token}` },
      })
        .then(res => res.json())
        .then(data => setUser(data.user))
        .catch(() => {});
    }
    
    fetch('/api/courses')
      .then(res => res.json())
      .then(data => setCourses(data.courses || []))
      .catch(() => {});
    
    fetch('/api/problems')
      .then(res => res.json())
      .then(data => setProblems(data.problems || []))
      .catch(() => {});
  }, []);

  const handleLogout = () => {
    localStorage.removeItem('token');
    setUser(null);
    window.location.href = '/';
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      {/* Navbar */}
      <nav className="bg-white shadow-lg">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16">
            <div className="flex items-center">
              <Link href="/" className="flex items-center space-x-2">
                <Code className="h-8 w-8 text-blue-600" />
                <span className="text-2xl font-bold text-gray-900">CodeLearn</span>
              </Link>
            </div>
            <div className="flex items-center space-x-4">
              <Link href="/courses" className="text-gray-700 hover:text-blue-600 px-3 py-2">
                Courses
              </Link>
              <Link href="/problems" className="text-gray-700 hover:text-blue-600 px-3 py-2">
                Problems
              </Link>
              {user ? (
                <>
                  <Link href="/dashboard" className="text-gray-700 hover:text-blue-600 px-3 py-2">
                    Dashboard
                  </Link>
                  <button
                    onClick={handleLogout}
                    className="bg-red-500 text-white px-4 py-2 rounded-lg hover:bg-red-600"
                  >
                    Logout
                  </button>
                </>
              ) : (
                <>
                  <Link href="/login" className="text-gray-700 hover:text-blue-600 px-3 py-2">
                    Login
                  </Link>
                  <Link href="/register" className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700">
                    Sign Up
                  </Link>
                </>
              )}
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="text-center">
          <h1 className="text-5xl font-bold text-gray-900 mb-6">
            Learn Coding. Practice Problems. Master Skills.
          </h1>
          <p className="text-xl text-gray-600 mb-8 max-w-2xl mx-auto">
            The ultimate platform combining Udemy-style courses with LeetCode-style practice problems
          </p>
          <div className="flex justify-center space-x-4">
            <Link
              href="/courses"
              className="bg-blue-600 text-white px-8 py-3 rounded-lg text-lg font-semibold hover:bg-blue-700 flex items-center space-x-2"
            >
              <BookOpen className="h-5 w-5" />
              <span>Browse Courses</span>
            </Link>
            <Link
              href="/problems"
              className="bg-green-600 text-white px-8 py-3 rounded-lg text-lg font-semibold hover:bg-green-700 flex items-center space-x-2"
            >
              <Code className="h-5 w-5" />
              <span>Solve Problems</span>
            </Link>
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-20">
          <div className="bg-white rounded-lg shadow-lg p-6 text-center">
            <Users className="h-12 w-12 text-blue-600 mx-auto mb-4" />
            <div className="text-3xl font-bold text-gray-900">50K+</div>
            <div className="text-gray-600">Active Students</div>
          </div>
          <div className="bg-white rounded-lg shadow-lg p-6 text-center">
            <BookOpen className="h-12 w-12 text-green-600 mx-auto mb-4" />
            <div className="text-3xl font-bold text-gray-900">{courses.length}+</div>
            <div className="text-gray-600">Courses Available</div>
          </div>
          <div className="bg-white rounded-lg shadow-lg p-6 text-center">
            <Code className="h-12 w-12 text-purple-600 mx-auto mb-4" />
            <div className="text-3xl font-bold text-gray-900">{problems.length}+</div>
            <div className="text-gray-600">Coding Problems</div>
          </div>
        </div>

        {/* Featured Courses */}
        <div className="mt-20">
          <h2 className="text-3xl font-bold text-gray-900 mb-8">Featured Courses</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {courses.slice(0, 3).map((course) => (
              <Link key={course.id} href={`/courses/${course.id}`}>
                <div className="bg-white rounded-lg shadow-lg overflow-hidden hover:shadow-xl transition">
                  <img
                    src={course.thumbnail}
                    alt={course.title}
                    className="w-full h-48 object-cover"
                  />
                  <div className="p-6">
                    <h3 className="text-xl font-bold text-gray-900 mb-2">{course.title}</h3>
                    <p className="text-gray-600 mb-4">{course.description}</p>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        <Star className="h-5 w-5 text-yellow-500 fill-current" />
                        <span className="text-gray-700">{course.rating}</span>
                        <span className="text-gray-500">({course.students} students)</span>
                      </div>
                      <div className="text-blue-600 font-bold">${course.price}</div>
                    </div>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </div>

        {/* Featured Problems */}
        <div className="mt-20">
          <h2 className="text-3xl font-bold text-gray-900 mb-8">Featured Problems</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {problems.slice(0, 3).map((problem) => (
              <Link key={problem.id} href={`/problems/${problem.id}`}>
                <div className="bg-white rounded-lg shadow-lg p-6 hover:shadow-xl transition">
                  <div className="flex items-center justify-between mb-4">
                    <span
                      className={`px-3 py-1 rounded-full text-sm font-semibold ${
                        problem.difficulty === 'easy'
                          ? 'bg-green-100 text-green-800'
                          : problem.difficulty === 'medium'
                          ? 'bg-yellow-100 text-yellow-800'
                          : 'bg-red-100 text-red-800'
                      }`}
                    >
                      {problem.difficulty}
                    </span>
                    <span className="text-gray-500">{problem.category}</span>
                  </div>
                  <h3 className="text-xl font-bold text-gray-900 mb-2">{problem.title}</h3>
                  <p className="text-gray-600 mb-4 line-clamp-2">{problem.description}</p>
                  <div className="flex items-center justify-between text-sm text-gray-500">
                    <span>Acceptance: {problem.acceptance}%</span>
                    <span>{problem.submissions} submissions</span>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

