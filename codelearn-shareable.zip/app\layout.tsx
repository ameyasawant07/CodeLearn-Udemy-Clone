import type { Metadata } from 'next'
import './globals.css'

export const metadata: Metadata = {
  title: 'CodeLearn - Learn & Practice Coding',
  description: 'The ultimate platform for learning coding through courses and practicing with coding problems',
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  )
}

